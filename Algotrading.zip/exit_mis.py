#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 14 11:35:33 2023

@author: nikhilsama
"""
import kite_init as ki 

kite, kws = ki.initKiteTicker()
ki.exit_positions(kite)            
